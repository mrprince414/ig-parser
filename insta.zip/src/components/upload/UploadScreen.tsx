import React, { useState, useRef } from "react";
import { UploadCloud, FileJson, AlertCircle } from "lucide-react";

interface UploadScreenProps {
  onFileSelect: (file: File) => void;
  onLoadDemo: () => void;
  isParsing: boolean;
  error: string | null;
}

export function UploadScreen({ onFileSelect, onLoadDemo, isParsing, error }: UploadScreenProps) {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.name.endsWith('.json') || file.type === 'application/json') {
        onFileSelect(file);
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFileSelect(e.target.files[0]);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex flex-col items-center justify-center p-4">
      <div className="max-w-md w-full flex flex-col items-center text-center space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Instagram Archive</h1>
          <p className="text-gray-500 dark:text-gray-400">Your private message history viewer</p>
        </div>

        {error && (
          <div className="w-full bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-400 px-4 py-3 rounded-xl flex items-start gap-3 text-left">
            <AlertCircle className="shrink-0 mt-0.5" size={18} />
            <div>
              <h3 className="font-medium">Failed to parse JSON</h3>
              <p className="text-sm opacity-90">{error}</p>
            </div>
          </div>
        )}

        <div
          className={`w-full max-w-sm rounded-3xl border-2 border-dashed transition-all duration-200 ${
            isDragging
              ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-500/10 scale-105"
              : "border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 hover:border-indigo-400 dark:hover:border-indigo-500"
          } p-10 cursor-pointer`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
        >
          {isParsing ? (
            <div className="flex flex-col items-center gap-4">
              <div className="w-12 h-12 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
              <div>
                <p className="font-medium text-gray-900 dark:text-white">Reading archive...</p>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Parsing conversations</p>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-4">
              <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center text-gray-500 dark:text-gray-400">
                <UploadCloud size={32} />
              </div>
              <div>
                <p className="font-medium text-gray-900 dark:text-white">Upload JSON</p>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                  Drag & drop or click to choose
                </p>
              </div>
            </div>
          )}
          <input
            type="file"
            ref={fileInputRef}
            className="hidden"
            accept=".json,application/json"
            onChange={handleFileChange}
            disabled={isParsing}
          />
        </div>

        <div className="flex flex-col items-center gap-4 pt-4">
          <p className="text-xs text-gray-400 dark:text-gray-500 max-w-xs text-center flex items-center gap-1">
             Your data stays in your browser. Nothing is uploaded anywhere.
          </p>

          <button
            onClick={onLoadDemo}
            disabled={isParsing}
            className="flex items-center gap-2 text-sm text-indigo-600 dark:text-indigo-400 font-medium hover:underline disabled:opacity-50"
          >
            <FileJson size={16} />
            Load Demo Archive
          </button>
        </div>
      </div>
    </div>
  );
}
