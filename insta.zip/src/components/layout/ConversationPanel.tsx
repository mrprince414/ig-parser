import React from "react";
import { Conversation } from "../../parser/types";
import { MessageTimeline } from "../messages/MessageTimeline";
import { Avatar } from "../ui/Avatar";
import { ArrowLeft } from "lucide-react";
import { EmptyState } from "../ui/EmptyState";

interface ConversationPanelProps {
  conversation: Conversation | null;
  onBack: () => void;
  onMediaClick?: (url: string, type: "photo" | "video") => void;
}

export function ConversationPanel({ conversation, onBack, onMediaClick }: ConversationPanelProps) {
  if (!conversation) {
    return (
      <div className="hidden md:flex flex-col h-full bg-gray-50 dark:bg-gray-900 border-l border-gray-200 dark:border-gray-800">
        <EmptyState />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-white dark:bg-gray-950">
      {/* Header */}
      <div className="h-16 px-4 border-b border-gray-200 dark:border-gray-800 flex items-center gap-3 shrink-0 bg-white/80 dark:bg-gray-950/80 backdrop-blur-md z-10">
        <button
          onClick={onBack}
          className="md:hidden p-2 -ml-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          aria-label="Back to conversations"
        >
          <ArrowLeft size={20} className="text-gray-900 dark:text-gray-100" />
        </button>
        <Avatar
          src={conversation.participant.avatar}
          alt={conversation.participant.displayName}
          size="sm"
        />
        <div className="flex flex-col">
          <span className="font-semibold text-gray-900 dark:text-white leading-tight">
            {conversation.participant.displayName}
          </span>
          <span className="text-xs text-gray-500 dark:text-gray-400 leading-tight">
            @{conversation.participant.username}
          </span>
        </div>
      </div>

      {/* Messages */}
      <MessageTimeline conversation={conversation} onMediaClick={onMediaClick} />
    </div>
  );
}
