import React from "react";
import { ThemeSwitcher } from "../ui/ThemeSwitcher";
import { FolderUp } from "lucide-react";

interface AppShellProps {
  sidebar: React.ReactNode;
  main: React.ReactNode;
  showMainOnMobile: boolean;
  onReset?: () => void;
}

export function AppShell({ sidebar, main, showMainOnMobile, onReset }: AppShellProps) {
  return (
    <div className="h-screen w-full flex flex-col bg-white dark:bg-gray-950 overflow-hidden">
      {/* Top Navbar */}
      <header className="h-14 shrink-0 border-b border-gray-200 dark:border-gray-800 flex items-center justify-between px-4 bg-white dark:bg-gray-950 z-20">
        <div className="flex items-center gap-2">
          <div className="font-semibold text-lg bg-gradient-to-tr from-indigo-500 to-purple-500 bg-clip-text text-transparent">
            Archive Viewer
          </div>
        </div>
        <div className="flex items-center gap-2">
          {onReset && (
            <button
              onClick={onReset}
              className="hidden sm:flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white px-3 py-1.5 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              title="Load another archive"
            >
              <FolderUp size={16} />
              <span>Load another</span>
            </button>
          )}
          <ThemeSwitcher />
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Sidebar (Conversations List) */}
        <div
          className={`w-full md:w-[320px] lg:w-[360px] flex-shrink-0 h-full overflow-hidden transition-transform duration-300 absolute md:relative z-10 md:z-0 md:translate-x-0 ${
            showMainOnMobile ? "-translate-x-full" : "translate-x-0"
          }`}
        >
          {sidebar}
        </div>

        {/* Main Panel (Selected Conversation) */}
        <div
          className={`flex-1 h-full w-full absolute md:relative z-20 md:z-0 transition-transform duration-300 md:translate-x-0 bg-white dark:bg-gray-950 ${
            showMainOnMobile ? "translate-x-0" : "translate-x-full"
          }`}
        >
          {main}
        </div>
      </div>
    </div>
  );
}
