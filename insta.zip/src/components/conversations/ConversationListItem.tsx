import React from "react";
import { Conversation } from "../../parser/types";
import { Avatar } from "../ui/Avatar";
import { formatTimestamp } from "../../utils/dates";
import { getMessagePreview } from "../../utils/messagePreview";

interface ConversationListItemProps {
  conversation: Conversation;
  isSelected: boolean;
  onClick: () => void;
}

export function ConversationListItem({
  conversation,
  isSelected,
  onClick,
}: ConversationListItemProps) {
  const lastMessage =
    conversation.messages.length > 0
      ? conversation.messages[conversation.messages.length - 1]
      : null;

  return (
    <button
      onClick={onClick}
      className={`w-full text-left px-4 py-3 flex items-center gap-3 transition-colors ${
        isSelected
          ? "bg-gray-100 dark:bg-gray-800"
          : "hover:bg-gray-50 dark:hover:bg-gray-900/50"
      }`}
    >
      <Avatar
        src={conversation.participant.avatar}
        alt={conversation.participant.displayName}
        size="lg"
      />
      <div className="flex-1 min-w-0 flex flex-col justify-center">
        <div className="flex items-center justify-between gap-2 mb-0.5">
          <span className="font-semibold text-gray-900 dark:text-white truncate">
            {conversation.participant.displayName}
          </span>
          {lastMessage && (
            <span className="text-xs text-gray-500 dark:text-gray-400 shrink-0 whitespace-nowrap">
              {formatTimestamp(lastMessage.timestamp)}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1 text-sm text-gray-500 dark:text-gray-400 truncate">
          {lastMessage ? (
            <span className="truncate">{getMessagePreview(lastMessage)}</span>
          ) : (
            <span className="italic opacity-70">No messages</span>
          )}
        </div>
      </div>
    </button>
  );
}
