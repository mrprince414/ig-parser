import React from "react";
import { Message } from "../../parser/types";
import { TextMessage } from "./TextMessage";
import { PhotoMessage } from "./PhotoMessage";
import { VideoMessage } from "./VideoMessage";
import { ReelMessage } from "./ReelMessage";
import { AudioMessage } from "./AudioMessage";
import { CallMessage } from "./CallMessage";
import { 
  ReactionMessage, 
  SystemMessage, 
  SharedPostMessage, 
  UnknownMessage 
} from "./OtherMessages";

interface MessageRendererProps {
  message: Message;
  onMediaClick?: (url: string, type: "photo" | "video") => void;
}

export function MessageRenderer({ message, onMediaClick }: MessageRendererProps) {
  switch (message.type) {
    case "text":
      return <TextMessage message={message} />;
    case "photo":
      return <PhotoMessage message={message} onMediaClick={onMediaClick} />;
    case "video":
      return <VideoMessage message={message} onMediaClick={onMediaClick} />;
    case "reel":
      return <ReelMessage message={message} onMediaClick={onMediaClick} />;
    case "audio":
      return <AudioMessage message={message} />;
    case "audio_call":
    case "video_call":
      return <CallMessage message={message} />;
    case "shared_post":
      return <SharedPostMessage message={message} onMediaClick={onMediaClick} />;
    case "reaction":
      return <ReactionMessage message={message} />;
    case "system":
      return <SystemMessage message={message} />;
    case "unknown":
    default:
      return <UnknownMessage message={message} />;
  }
}
