import React, { useState, useRef, useEffect } from "react";
import { Message } from "../../parser/types";
import { Play, Pause } from "lucide-react";
import { MessageBubble } from "./TextMessage";

export function AudioMessage({ message }: { message: Message }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (message.media?.url) {
      const audio = new Audio(message.media.url);
      
      const updateTime = () => {
        setCurrentTime(audio.currentTime);
        if (audio.duration) {
          setProgress((audio.currentTime / audio.duration) * 100);
        }
      };
      
      const onEnded = () => {
        setIsPlaying(false);
        setProgress(0);
        setCurrentTime(0);
      };

      audio.addEventListener('timeupdate', updateTime);
      audio.addEventListener('ended', onEnded);
      audioRef.current = audio;
      
      return () => {
        audio.removeEventListener('timeupdate', updateTime);
        audio.removeEventListener('ended', onEnded);
        audio.pause();
        audio.src = '';
      };
    }
  }, [message.media?.url]);

  const togglePlay = () => {
    if (!audioRef.current) {
      setIsPlaying(!isPlaying);
      return;
    }
    
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch(err => {
        console.error("Audio playback error:", err);
        setIsPlaying(false);
      });
    }
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = Math.max(0, Math.min(1, x / rect.width));
    
    if (audioRef.current && audioRef.current.duration) {
      audioRef.current.currentTime = percentage * audioRef.current.duration;
      setProgress(percentage * 100);
    } else if (!audioRef.current) {
      // Fake seek
      setProgress(percentage * 100);
      if (message.media?.duration) {
        setCurrentTime(percentage * message.media.duration);
      }
    }
  };

  useEffect(() => {
    // Fake progress for dummy data
    let interval: any;
    if (isPlaying && !audioRef.current) {
      const duration = message.media?.duration || 60;
      interval = setInterval(() => {
        setProgress(p => {
          if (p >= 100) {
            setIsPlaying(false);
            setCurrentTime(0);
            return 0;
          }
          const newProgress = p + (100 / (duration * 10)); // assuming 100ms interval
          setCurrentTime((newProgress / 100) * duration);
          return newProgress;
        });
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isPlaying, message.media?.duration]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const durationStr = message.media?.duration ? formatTime(message.media.duration) : '0:00';
  const currentTimeStr = formatTime(currentTime);

  return (
    <MessageBubble message={message}>
      <div className="flex items-center gap-3 min-w-[200px]">
        <button 
          onClick={togglePlay}
          className={`w-10 h-10 shrink-0 rounded-full flex items-center justify-center transition-colors ${
            message.sender === 'me' 
              ? 'bg-blue-600 hover:bg-blue-700 text-white' 
              : 'bg-indigo-500 hover:bg-indigo-600 text-white'
          }`}
        >
          {isPlaying ? <Pause size={20} fill="currentColor" /> : <Play size={20} className="ml-0.5" fill="currentColor" />}
        </button>
        
        <div className="flex-1 flex flex-col justify-center gap-1.5">
          <div 
            className="h-1.5 w-full bg-black/10 dark:bg-white/10 rounded-full overflow-hidden cursor-pointer py-2 -my-2 flex items-center"
            onClick={handleSeek}
          >
            <div className="h-1.5 w-full bg-black/10 dark:bg-white/10 rounded-full overflow-hidden pointer-events-none">
              <div 
                className={`h-full rounded-full transition-all duration-100 ${message.sender === 'me' ? 'bg-white' : 'bg-indigo-500'}`}
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
          <div className="flex justify-between items-center text-[11px] opacity-75">
            <span>{currentTime > 0 ? currentTimeStr : durationStr}</span>
          </div>
        </div>
      </div>
    </MessageBubble>
  );
}
