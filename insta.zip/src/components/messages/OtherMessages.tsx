import React from "react";
import { Message } from "../../parser/types";
import { Heart, Info, Box } from "lucide-react";
import { MessageBubble } from "./TextMessage";

export function ReactionMessage({ message }: { message: Message }) {
  return (
    <div className="flex w-full justify-center my-2">
      <div className="text-sm text-gray-500 dark:text-gray-400 flex items-center gap-2">
        <Heart size={14} className="text-red-500" fill="currentColor" />
        <span>{message.sender === "me" ? "You" : "They"} reacted {message.text || "❤️"}</span>
      </div>
    </div>
  );
}

export function SystemMessage({ message }: { message: Message }) {
  return (
    <div className="flex w-full justify-center my-3">
      <div className="bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 text-xs px-3 py-1.5 rounded-full font-medium">
        {message.text || "System message"}
      </div>
    </div>
  );
}

export function UnknownMessage({ message }: { message: Message }) {
  return (
    <MessageBubble message={message}>
      <div className="flex items-start gap-3 opacity-70">
        <Box size={20} className="mt-0.5 shrink-0" />
        <div className="flex flex-col">
          <span className="font-medium text-sm">Unsupported message</span>
          <span className="text-xs opacity-75">This content type cannot currently be displayed.</span>
        </div>
      </div>
    </MessageBubble>
  );
}

export function SharedPostMessage({ message, onMediaClick }: { message: Message, onMediaClick?: (url: string, type: "photo") => void }) {
  const isMe = message.sender === "me";

  return (
    <div className={`flex w-full ${isMe ? "justify-end" : "justify-start"} mb-1`}>
      <div className={`group max-w-[85%] md:max-w-[280px] w-full flex flex-col rounded-2xl overflow-hidden border border-gray-200 dark:border-gray-700/50 bg-white dark:bg-gray-800 ${isMe ? "rounded-br-sm" : "rounded-bl-sm"}`}>
        <div className="p-3 border-b border-gray-100 dark:border-gray-700/50 flex items-center gap-2">
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-gray-900 dark:text-white truncate">
              {message.metadata?.creator ? String(message.metadata.creator) : 'Instagram Post'}
            </p>
          </div>
        </div>

        <div 
          className="relative aspect-square bg-gray-100 dark:bg-gray-900 cursor-pointer overflow-hidden flex items-center justify-center"
          onClick={() => {
            if (message.media?.thumbnail && onMediaClick) {
              onMediaClick(message.media.thumbnail, 'photo');
            } else if (message.media?.url && onMediaClick) {
              onMediaClick(message.media.url, 'photo');
            }
          }}
        >
          {message.media?.thumbnail || message.media?.url ? (
            <img 
              src={message.media.thumbnail || message.media.url} 
              alt="Shared post" 
              className="w-full h-full object-cover"
            />
          ) : (
            <span className="text-gray-400 text-sm">Media unavailable</span>
          )}
        </div>

        {message.metadata?.caption && (
          <div className="p-3 text-sm text-gray-700 dark:text-gray-300">
            <p className="line-clamp-2">{String(message.metadata.caption)}</p>
          </div>
        )}
      </div>
    </div>
  );
}
