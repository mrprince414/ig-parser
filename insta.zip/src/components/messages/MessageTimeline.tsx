import React, { useMemo } from "react";
import { Conversation } from "../../parser/types";
import { MessageRenderer } from "./MessageRenderer";
import { formatDateGroup } from "../../utils/dates";

interface MessageTimelineProps {
  conversation: Conversation;
  onMediaClick?: (url: string, type: "photo" | "video") => void;
}

export function MessageTimeline({ conversation, onMediaClick }: MessageTimelineProps) {
  // Group messages by date
  const groupedMessages = useMemo(() => {
    const groups: { date: string; messages: typeof conversation.messages }[] = [];
    let currentGroup: typeof groups[0] | null = null;
    let currentDateStr = "";

    conversation.messages.forEach((msg) => {
      const dateStr = new Date(msg.timestamp).toDateString();
      if (dateStr !== currentDateStr) {
        currentDateStr = dateStr;
        currentGroup = {
          date: formatDateGroup(msg.timestamp),
          messages: [],
        };
        groups.push(currentGroup);
      }
      currentGroup?.messages.push(msg);
    });

    return groups;
  }, [conversation.messages]);

  return (
    <div className="flex-1 overflow-y-auto bg-white dark:bg-gray-950 p-4 scroll-smooth">
      <div className="flex flex-col min-h-full justify-end">
        {groupedMessages.map((group, groupIdx) => (
          <div key={groupIdx} className="mb-6">
            <div className="flex justify-center mb-4 sticky top-2 z-10 pointer-events-none">
              <span className="bg-gray-100/90 dark:bg-gray-800/90 backdrop-blur-sm text-gray-500 dark:text-gray-400 text-xs font-semibold px-3 py-1 rounded-full shadow-sm">
                {group.date}
              </span>
            </div>
            <div className="flex flex-col gap-1">
              {group.messages.map((message, i) => (
                <MessageRenderer
                  key={message.id}
                  message={message}
                  onMediaClick={onMediaClick}
                />
              ))}
            </div>
          </div>
        ))}
        {conversation.messages.length === 0 && (
          <div className="flex-1 flex items-center justify-center text-gray-500 dark:text-gray-400 p-8 text-center h-full">
            No messages found in this conversation.
          </div>
        )}
      </div>
    </div>
  );
}
