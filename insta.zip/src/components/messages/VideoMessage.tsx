import React, { useState } from "react";
import { Message } from "../../parser/types";
import { Film, Play } from "lucide-react";
import { formatTimeOnly } from "../../utils/dates";

interface MediaMessageProps {
  message: Message;
  onMediaClick?: (url: string, type: "photo" | "video") => void;
}

export function VideoMessage({ message, onMediaClick }: MediaMessageProps) {
  const [error, setError] = useState(false);
  const isMe = message.sender === "me";

  return (
    <div className={`flex w-full ${isMe ? "justify-end" : "justify-start"} mb-1`}>
      <div className="relative group max-w-[85%] md:max-w-[60%]">
        <div
          className={`overflow-hidden rounded-2xl cursor-pointer ${
            isMe ? "rounded-br-sm" : "rounded-bl-sm"
          } bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700/50 flex flex-col items-center justify-center min-h-[150px] min-w-[200px] relative`}
          onClick={() => {
            if (!error && message.media?.url && onMediaClick) {
              onMediaClick(message.media.url, "video");
            }
          }}
        >
          {error || !message.media?.url ? (
            <div className="flex flex-col items-center gap-2 p-6 text-gray-400">
              <Film size={32} />
              <span className="text-sm font-medium">Video unavailable</span>
            </div>
          ) : (
            <>
              {message.media.thumbnail ? (
                <>
                  <img
                    src={message.media.thumbnail}
                    alt="Video thumbnail"
                    className="w-full h-auto object-cover max-h-[400px]"
                    onError={() => setError(true)}
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-12 h-12 bg-black/50 rounded-full flex items-center justify-center text-white backdrop-blur-sm">
                      <Play size={24} className="ml-1" fill="currentColor" />
                    </div>
                  </div>
                </>
              ) : (
                <video
                  src={message.media.url}
                  className="w-full max-h-[400px] object-cover"
                  onError={() => setError(true)}
                  controls={false}
                  preload="metadata"
                />
              )}
            </>
          )}
        </div>
        <div className="text-[11px] font-medium leading-none absolute bottom-2 right-3 bg-black/50 text-white px-2 py-1 rounded-full backdrop-blur-sm pointer-events-none">
          {formatTimeOnly(message.timestamp)}
        </div>
      </div>
    </div>
  );
}
