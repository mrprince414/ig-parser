import React from "react";
import { Message } from "../../parser/types";
import { formatTimeOnly } from "../../utils/dates";

interface BaseProps {
  message: Message;
  children: React.ReactNode;
}

export function MessageBubble({ message, children }: BaseProps) {
  const isMe = message.sender === "me";
  
  return (
    <div className={`flex w-full ${isMe ? "justify-end" : "justify-start"} mb-1`}>
      <div
        className={`relative group max-w-[85%] md:max-w-[70%] rounded-2xl px-4 py-2 flex flex-col gap-1 ${
          isMe
            ? "bg-blue-500 text-white rounded-br-sm"
            : "bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-gray-100 rounded-bl-sm border border-gray-200 dark:border-gray-700/50"
        }`}
      >
        <div className="break-words whitespace-pre-wrap">{children}</div>
        <div 
          className={`text-[11px] font-medium leading-none self-end mt-1 ${
            isMe ? "text-blue-100" : "text-gray-400 dark:text-gray-500"
          }`}
        >
          {formatTimeOnly(message.timestamp)}
        </div>
      </div>
    </div>
  );
}

export function TextMessage({ message }: { message: Message }) {
  // Check for urls to make them clickable
  const renderText = (text: string) => {
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    return text.split(urlRegex).map((part, i) => {
      if (part.match(urlRegex)) {
        return (
          <a
            key={i}
            href={part}
            target="_blank"
            rel="noopener noreferrer"
            className="underline underline-offset-2 break-all"
          >
            {part}
          </a>
        );
      }
      return part;
    });
  };

  return (
    <MessageBubble message={message}>
      {message.text ? renderText(message.text) : null}
    </MessageBubble>
  );
}
