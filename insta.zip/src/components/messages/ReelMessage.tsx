import React from "react";
import { Message } from "../../parser/types";
import { Play } from "lucide-react";

export function ReelMessage({ message, onMediaClick }: { message: Message, onMediaClick?: (url: string, type: "photo" | "video") => void }) {
  const isMe = message.sender === "me";

  return (
    <div className={`flex w-full ${isMe ? "justify-end" : "justify-start"} mb-1`}>
      <div className={`group max-w-[85%] md:max-w-[280px] w-full flex flex-col rounded-2xl overflow-hidden border border-gray-200 dark:border-gray-700/50 bg-white dark:bg-gray-800 ${isMe ? "rounded-br-sm" : "rounded-bl-sm"}`}>
        
        <div className="p-3 bg-gray-50 dark:bg-gray-800/80 border-b border-gray-100 dark:border-gray-700/50 flex items-center gap-2">
          <div className="w-6 h-6 rounded-md bg-gradient-to-tr from-yellow-400 via-pink-500 to-purple-600 flex items-center justify-center text-white shrink-0">
            <Play size={12} fill="currentColor" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-gray-900 dark:text-white truncate">
              {message.metadata?.creator ? String(message.metadata.creator) : 'Instagram Reel'}
            </p>
          </div>
        </div>

        <div 
          className="relative aspect-[9/16] bg-gray-100 dark:bg-gray-900 cursor-pointer overflow-hidden flex items-center justify-center"
          onClick={() => {
            if (message.media?.url && onMediaClick) {
              onMediaClick(message.media.url, 'video');
            }
          }}
        >
          {message.media?.thumbnail ? (
            <img 
              src={message.media.thumbnail} 
              alt="Reel thumbnail" 
              className="w-full h-full object-cover"
            />
          ) : message.media?.url ? (
            <video src={message.media.url} className="w-full h-full object-cover" />
          ) : (
            <span className="text-gray-400 text-sm">Media unavailable</span>
          )}
          
          <div className="absolute inset-0 flex items-center justify-center bg-black/10 group-hover:bg-black/20 transition-colors">
            <div className="w-12 h-12 bg-black/40 rounded-full flex items-center justify-center text-white backdrop-blur-sm">
              <Play size={24} className="ml-1" fill="currentColor" />
            </div>
          </div>
        </div>

        {message.text && (
          <div className="p-3 text-sm text-gray-700 dark:text-gray-300">
            <p className="line-clamp-2">{message.text}</p>
          </div>
        )}
      </div>
    </div>
  );
}
