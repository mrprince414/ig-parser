import React from "react";
import { Message } from "../../parser/types";
import { Phone, PhoneMissed, Video } from "lucide-react";
import { formatTimeOnly } from "../../utils/dates";

export function CallMessage({ message }: { message: Message }) {
  const isVideo = message.type === "video_call";
  const isMissed = String(message.metadata?.status || '').toLowerCase().includes("missed");
  const duration = message.metadata?.duration;
  const isMe = message.sender === "me";

  return (
    <div className={`flex w-full ${isMe ? "justify-end" : "justify-start"} my-2`}>
      <div className={`bg-gray-100 dark:bg-gray-800/80 border border-gray-200 dark:border-gray-700 px-4 py-3 rounded-2xl flex flex-col items-center gap-1 text-center max-w-[240px] ${
        isMe ? "rounded-br-sm" : "rounded-bl-sm"
      }`}>
        <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-1 ${
          isMissed 
            ? "bg-red-100 text-red-500 dark:bg-red-500/20 dark:text-red-400" 
            : "bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300"
        }`}>
          {isVideo ? (
             <Video size={20} />
          ) : (
            isMissed ? <PhoneMissed size={20} /> : <Phone size={20} />
          )}
        </div>
        <div className="font-semibold text-gray-900 dark:text-gray-100 text-sm">
          {isVideo ? "Video call" : "Audio call"}
        </div>
        <div className="text-xs text-gray-500 dark:text-gray-400">
          {isMissed ? "Missed call" : (duration || "Completed")}
        </div>
        <div className="text-[11px] text-gray-400 mt-1">
          {formatTimeOnly(message.timestamp)}
        </div>
      </div>
    </div>
  );
}
