import React from 'react';
import { MessageCircle } from 'lucide-react';

export function EmptyState() {
  return (
    <div className="flex-1 flex flex-col items-center justify-center h-full text-center p-8 text-gray-500 dark:text-gray-400">
      <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mb-6">
        <MessageCircle size={32} className="text-gray-400 dark:text-gray-500" />
      </div>
      <h3 className="text-xl font-medium text-gray-900 dark:text-white mb-2">Select a conversation</h3>
      <p className="max-w-md">Choose a conversation from the list to view its history.</p>
    </div>
  );
}
