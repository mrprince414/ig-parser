import React, { useEffect, useState } from "react";
import { X } from "lucide-react";

interface MediaViewerProps {
  url: string;
  type: "photo" | "video";
  onClose: () => void;
}

export function MediaViewer({ url, type, onClose }: MediaViewerProps) {
  const [loading, setLoading] = useState(true);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm p-4">
      <button
        onClick={onClose}
        className="absolute top-4 right-4 p-2 text-white/70 hover:text-white bg-black/20 hover:bg-black/40 rounded-full transition-all z-10"
        aria-label="Close fullscreen media viewer"
      >
        <X size={24} />
      </button>

      <div
        className="relative max-w-full max-h-full flex items-center justify-center"
        onClick={(e) => e.stopPropagation()}
      >
        {loading && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-8 h-8 border-4 border-white/20 border-t-white rounded-full animate-spin"></div>
          </div>
        )}

        {type === "photo" ? (
          <img
            src={url}
            alt="Fullscreen media"
            className={`max-w-full max-h-[90vh] object-contain transition-opacity duration-300 ${
              loading ? "opacity-0" : "opacity-100"
            }`}
            onLoad={() => setLoading(false)}
            onError={() => setLoading(false)}
          />
        ) : (
          <video
            src={url}
            controls
            autoPlay
            className={`max-w-full max-h-[90vh] object-contain transition-opacity duration-300 ${
              loading ? "opacity-0" : "opacity-100"
            }`}
            onLoadedData={() => setLoading(false)}
            onError={() => setLoading(false)}
          />
        )}
      </div>
    </div>
  );
}
