import { Conversation, Message, Participant } from "./types";

export function parseDummyJson(rawJson: any): Conversation[] {
  if (!rawJson || !rawJson.users || typeof rawJson.users !== "object") {
    throw new Error("Invalid dummy JSON format");
  }

  const conversations: Conversation[] = [];

  for (const [key, userData] of Object.entries(rawJson.users)) {
    const data = userData as any;

    const participant: Participant = {
      id: data.id || key,
      username: data.username || key,
      displayName: data.name || data.username || "Unknown User",
      avatar: data.avatar,
    };

    const messages: Message[] = (data.messages || []).map((msg: any) => ({
      id: msg.id || Math.random().toString(36).substr(2, 9),
      type: msg.type || "unknown",
      sender: msg.sender === "me" ? "me" : "them",
      timestamp: msg.timestamp || new Date().toISOString(),
      text: msg.text,
      media: msg.media,
      metadata: msg.metadata,
    }));

    // Sort messages chronologically
    messages.sort(
      (a, b) =>
        new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );

    conversations.push({
      id: `conv_${participant.id}`,
      participant,
      messages,
    });
  }

  // Sort conversations by most recent message
  conversations.sort((a, b) => {
    const latestA = a.messages[a.messages.length - 1]?.timestamp || 0;
    const latestB = b.messages[b.messages.length - 1]?.timestamp || 0;
    return new Date(latestB).getTime() - new Date(latestA).getTime();
  });

  return conversations;
}
