export type MessageType =
  | "text"
  | "photo"
  | "video"
  | "reel"
  | "audio"
  | "audio_call"
  | "video_call"
  | "shared_post"
  | "reaction"
  | "system"
  | "unknown";

export interface MediaData {
  url?: string;
  thumbnail?: string;
  width?: number;
  height?: number;
  duration?: number;
}

export interface Message {
  id: string;
  type: MessageType;
  sender: "me" | "them";
  timestamp: string;
  text?: string;
  media?: MediaData;
  metadata?: Record<string, unknown>;
}

export interface Participant {
  id: string;
  username: string;
  displayName: string;
  avatar?: string;
}

export interface Conversation {
  id: string;
  participant: Participant;
  messages: Message[];
}
