import React, { useState } from 'react';
import { ThemeProvider } from './components/ui/ThemeToggle';
import { UploadScreen } from './components/upload/UploadScreen';
import { AppShell } from './components/layout/AppShell';
import { ConversationList } from './components/conversations/ConversationList';
import { ConversationPanel } from './components/layout/ConversationPanel';
import { MediaViewer } from './components/media/MediaViewer';
import { Conversation } from './parser/types';
import { parseDummyJson } from './parser/dummyParser';
import dummyData from './data/dummyData.json';

export default function App() {
  const [appState, setAppState] = useState<'upload' | 'parsing' | 'archive'>('upload');
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConvId, setSelectedConvId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Fullscreen media state
  const [mediaViewer, setMediaViewer] = useState<{ url: string; type: 'photo' | 'video' } | null>(null);

  const handleLoadDemo = () => {
    setAppState('parsing');
    setError(null);
    
    // Simulate slight delay for effect
    setTimeout(() => {
      try {
        const parsed = parseDummyJson(dummyData);
        setConversations(parsed);
        setAppState('archive');
      } catch (err: any) {
        setError(err.message || "Failed to load demo data.");
        setAppState('upload');
      }
    }, 800);
  };

  const handleFileUpload = (file: File) => {
    setAppState('parsing');
    setError(null);
    
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const rawJson = JSON.parse(content);
        
        // Use dummy parser for now as requested. 
        // In the future this will be replaced with real Instagram JSON parser
        const parsed = parseDummyJson(rawJson);
        setConversations(parsed);
        setAppState('archive');
      } catch (err: any) {
        console.error(err);
        setError("Invalid JSON format. Please upload a valid archive.");
        setAppState('upload');
      }
    };
    reader.onerror = () => {
      setError("Failed to read file.");
      setAppState('upload');
    };
    
    // Simulate slight delay to show loading state if file is small
    setTimeout(() => {
      reader.readAsText(file);
    }, 500);
  };

  const handleReset = () => {
    setAppState('upload');
    setConversations([]);
    setSelectedConvId(null);
    setError(null);
  };

  const selectedConversation = conversations.find(c => c.id === selectedConvId) || null;

  return (
    <ThemeProvider>
      {appState === 'upload' || appState === 'parsing' ? (
        <UploadScreen
          onFileSelect={handleFileUpload}
          onLoadDemo={handleLoadDemo}
          isParsing={appState === 'parsing'}
          error={error}
        />
      ) : (
        <AppShell
          onReset={handleReset}
          showMainOnMobile={selectedConvId !== null}
          sidebar={
            <ConversationList
              conversations={conversations}
              selectedId={selectedConvId}
              onSelect={(id) => setSelectedConvId(id)}
            />
          }
          main={
            <ConversationPanel
              conversation={selectedConversation}
              onBack={() => setSelectedConvId(null)}
              onMediaClick={(url, type) => setMediaViewer({ url, type })}
            />
          }
        />
      )}

      {mediaViewer && (
        <MediaViewer
          url={mediaViewer.url}
          type={mediaViewer.type}
          onClose={() => setMediaViewer(null)}
        />
      )}
    </ThemeProvider>
  );
}
