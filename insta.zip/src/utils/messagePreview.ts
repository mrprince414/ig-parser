import { Message } from "../parser/types";

export function getMessagePreview(message: Message): string {
  if (message.type === 'text' && message.text) {
    return message.text;
  }
  
  const prefixes = {
    photo: '📷 Photo',
    video: '🎞️ Video',
    reel: '🎞️ Shared a reel',
    audio: '🎵 Voice message',
    audio_call: '📞 Audio call',
    video_call: '📹 Video call',
    shared_post: '🖼️ Shared a post',
    reaction: '❤️ Reaction',
    system: 'System message',
    unknown: 'Unsupported message'
  };

  return prefixes[message.type] || prefixes.unknown;
}
